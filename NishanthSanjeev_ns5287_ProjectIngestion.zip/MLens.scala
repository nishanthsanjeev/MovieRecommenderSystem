import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._


object MLens {
	def main(args : Array[String]) {
		val sc = new SparkContext()

		import org.apache.spark.sql.SparkSession
		
		val spark = SparkSession
		 .builder
		 .appName("MLensApp")
		 .getOrCreate()
		
		val movieSchema = "movieId INT, title STRING, genres STRING"
		val df_movies = spark.read.format("csv").schema(movieSchema).option("header", "true").load("ml-25m/movies.csv")
		//df_movies.show(25, false)

		val ratingSchema = "userId INT, movieId INT, rating DOUBLE, timestamp LONG"
		val df_ratings_timestamp = spark.read.format("csv").schema(ratingSchema).option("header", "true").load("ml-25m/ratings.csv")
		val df_ratings = df_ratings_timestamp.drop("timestamp")
		//df_ratings.show(25, false)

		val tagSchema = "userId INT, movieId INT, tag STRING, timestamp LONG"
		val df_tags_timestamp = spark.read.format("csv").schema(tagSchema).option("header", "true").load("ml-25m/tags.csv")
		val df_tags = df_tags_timestamp.drop("timestamp")
		//df_tags.show(25, false)
		
		sc.stop()
	}
}